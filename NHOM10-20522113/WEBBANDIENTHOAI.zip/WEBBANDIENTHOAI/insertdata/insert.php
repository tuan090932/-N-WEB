<?php

require_once ('../config/config.php');
$sql = "CREATE TABLE users( ".
"id INT NOT NULL AUTO_INCREMENT, ".
"username VARCHAR(100) NOT NULL, ".
"email VARCHAR(40) NOT NULL, ".
"password VARCHAR(40) NOT NULL, ".
"create_datetime datetime NOT NULL,".
"PRIMARY KEY ( id )); ";

$mysqli->query($sql);




$sql = "CREATE TABLE product( ".
"id INT NOT NULL AUTO_INCREMENT, ".
"name VARCHAR(100) NOT NULL, ".
"price VARCHAR(40) NOT NULL, ".
"image VARCHAR(40) NOT NULL, ".
"brand_id INT(40) NOT NULL, ".
"PRIMARY KEY ( id )); ";


$mysqli->query($sql);



$sql = "CREATE TABLE brand( ".
"id INT NOT NULL AUTO_INCREMENT, ".
"name VARCHAR(100) NOT NULL, ".
"PRIMARY KEY ( id )); ";
$mysqli->query($sql);



$sql = "CREATE TABLE bill( ".
"id INT NOT NULL AUTO_INCREMENT, ".
"name VARCHAR(100) NOT NULL, ".
"sdt INT(100) NOT NULL, ".
"mail VARCHAR(100) NOT NULL, ".
"noinhan VARCHAR(40) NOT NULL, ".
"gichu  VARCHAR(40) NOT NULL, ".
"tonggia  INT(40) NOT NULL, ".
"tinhtrang INT(40) NOT NULL, ". 
"ngaymua datetime NOT NULL, ".
"brand VARCHAR(40) NOT NULL, ". 
"loaisanpham VARCHAR(40) NOT NULL, ".
"PRIMARY KEY ( id )); ";

$mysqli->query($sql);





$sql = "CREATE TABLE adminne( ".
"id INT NOT NULL AUTO_INCREMENT, ".
"username VARCHAR(100) NOT NULL, ".
"password VARCHAR(40) NOT NULL, ".
"PRIMARY KEY ( id )); ";

$mysqli->query($sql);


$mysqli->query("INSERT INTO product (id,name, price, image,brand_id)
VALUES ('1','iphone-14pro', '20000', '../img/iphone-14pro.jpg',1)"); 
$mysqli->query("INSERT INTO product (id,name, price, image,brand_id)
VALUES ('2','iphone-14', '19000', '../img/iphone-14.jpg',1)"); 
$mysqli->query("INSERT INTO product (id,name, price, image,brand_id)
VALUES ('3','iphone-13promax', '21000', '../img/iphone-13promax.jpg',1)"); 
$mysqli->query("INSERT INTO product (id,name, price, image,brand_id)
VALUES ('4','iphone-13pro', '15000', '../img/iphone-13pro.jpg',1)"); 
$mysqli->query("INSERT INTO product (id,name, price, image,brand_id)
VALUES ('5','iphone-13', '14000', '../img/iphone-13.jpg',1)"); 







$mysqli->query("INSERT INTO product (id,name, price, image,brand_id)
VALUES ('6','vivo-v23', '10000', '../img/vivo-v23.jpg',2)"); 
$mysqli->query("INSERT INTO product (id,name, price, image,brand_id)
VALUES ('7','vivo-v25', '7000', '../img/vivo-v25.jpg',2)"); 
$mysqli->query("INSERT INTO product (id,name, price, image,brand_id)
VALUES ('8','vivo-v22', '6000', '../img/vivo-v22.jpg',2)"); 
$mysqli->query("INSERT INTO product (id,name, price, image,brand_id)
VALUES ('9','vivo-v21', '5000', '../img/vivo-v21.jpg',2)"); 








$mysqli->query("INSERT INTO product (id,name, price, image,brand_id)
VALUES ('10','nokia-c21', '14500', '../img/nokia-c21.jpg',3)"); 
$mysqli->query("INSERT INTO product (id,name, price, image,brand_id)
VALUES ('11','nokia-c31', '16000', '../img/nokia-c31.jpg',3)"); 
$mysqli->query("INSERT INTO product (id,name, price, image,brand_id)
VALUES ('12','nokia-g20', '11500', '../img/nokia-g20.jpg',3)"); 





$mysqli->query("INSERT INTO product (id,name, price, image,brand_id)
VALUES ('13','oppo-7', '3000', '../img/iphone-13promax.jpg',4)"); 
$mysqli->query("INSERT INTO product (id,name, price, image,brand_id)
VALUES ('14','oppo-6', '4000', '../img/iphone-13pro.jpg',4)"); 
$mysqli->query("INSERT INTO product (id,name, price, image,brand_id)
VALUES ('15','oppo-pro', '3400', '../img/iphone-13.jpg',4)"); 
$mysqli->query("INSERT INTO product (id,name, price, image,brand_id)
VALUES ('16','oppo-5', '5000', '../img/oppo-5.jpg',4)"); 






$mysqli->query("INSERT INTO product (id,name, price, image,brand_id)
VALUES ('17','xiaomi-11', '2000', '../img/xiaomi-11.jpg',5)"); 
$mysqli->query("INSERT INTO product (id,name, price, image,brand_id)
VALUES ('18','xiaomi-11-pro', '1000', '../img/xiaomi-11-pro.jpg',5)"); 
$mysqli->query("INSERT INTO product (id,name, price, image,brand_id)
VALUES ('19','xiaomi-12', '1500', '../img/xiaomi-12.jpg',5)"); 
$mysqli->query("INSERT INTO product (id,name, price, image,brand_id)
VALUES ('20','xiaomi-12-pro', '3000', '../img/xiaomi-12-pro.jpg',5)"); 









$mysqli->query("INSERT INTO brand (id,name) VALUES ('1','iphone')");
 


$mysqli->query("INSERT INTO brand (id,name) VALUES ('2','vivo')");
 


$mysqli->query("INSERT INTO brand (id,name) VALUES ('3','nokia')");
 


$mysqli->query("INSERT INTO brand (id,name) VALUES ('4','oppo')");
 


$mysqli->query("INSERT INTO brand (id,name) VALUES ('5','xiaomi')");
 

    


?>