<?php
    // Enter your host name, database username, password, and database name.
    // If you have not set database password on localhost then set empty.
    $mysqli = mysqli_connect("127.0.0.1:3307","root","","iphone");
    // Check connection
    if (mysqli_connect_errno()){
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
$retval = mysqli_select_db( $mysqli, 'iphone' );
if(! $retval ) {
   die('Could not select database: ' . mysqli_error($mysqli));
}




//if ($mysqli->query("Drop Table users")) {
// printf("Table tutorials_tbl dropped successfully.<br />");
//}

?>