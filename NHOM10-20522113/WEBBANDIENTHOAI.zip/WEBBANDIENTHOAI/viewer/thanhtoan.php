
<script>
    if ( window.history.replaceState ) {
        window.history.replaceState( null, null, window.location.href );
    }
</script>


<?php
// chia ra 2 trường hợp nesu có sản phẩm thì hiển thị còn nếu không có thì hiển thị file php của chuacosanpham.php
require_once ('auth_session.php');
if (isset($_POST['submit'])) {
    $_SESSION['idsanpham'] = $_POST['idsanpham'];
    //lấy id sản phẩm khi người dùng truy cập vào 1 sản phẩm 
}


if(!isset($_SESSION['idsanpham'])){
    include 'chuacosanphamtrongcart.php';
    exit();//EXIT này làm  ngưng các đoạn code ở dưới ngừng chạy để chỉ chạy code chuacosanpham
}
   ?>







<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="dashboard.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
</head>
<body style="wi">
<div>
<?php
include "header.php";

?>
</div>
<?php  


require_once ('../config/config.php');
$idsanphammua = $_SESSION['idsanpham'];//idproduct mua
//where id=$a
$sql = "SELECT  *FROM product where id=$idsanphammua";
$result = $mysqli->query($sql);
$row = $result->fetch_assoc();//vì nó lun lun trả về 1  sản phẩm nên ta  không cần dùng vòng while để lặp mà gán biến trực tiếp lun
$_SESSION['namesp'] = $row['name'];
$_SESSION['brandid'] = $row['brand_id'];//lưu 1 biến brand-> lưu thương hiệu
//lấy

//when dat attribute la name se khong xu ly sql dc thuoc tinh name nen ko nen dat no la name

?>         
<div style="margin:100px ;
   ">
<section class="row">
        <div class="col-md-6 col-sm-6 my-3 my-md-0 " >
            <div>
                 <h1 style="margin-left:50px;"> <?php echo $row['name']?> </h1>
                 <img  src="<?php echo $row["image"]?>" alt="Image1"class="img-fluid" alt="Responsive image"style="margin-top: 30px" >

                 <form class="form" action="xóa.php" method="post">
    
                     <input style="margin-left:70px;font-size: 20px; margin-top:20px" type="submit" name="submit" value="xóa" class="login-button">
                 </form>
            </div>
        </div>
        <div class="col-md-6 col-sm-6 my-3 my-md-0 " >
        <div class="row rounded  border border-primary text-center" style="background-color: lightblue;">
                <div class="col-12" >
                  <div >
                          <h3>giá sản phẩm là <?php echo $row["price"] ?> </h1>           
                  </div>
                </div>
            </div>

            <div class="row border-2 rounded  border border-primary" style="margin-top:30px;background-color: lightblue;">
                <div class="col-12" style="padding:20px">
                  <div >Ưu Đãi: 

Bộ Quà Tặng Google trị giá 1.490.000đ (Xem Chi Tiết) 
Samsung Care+ 6 Tháng
Trả Góp 0% | Phòng Chờ Hạng Thương Gia 
Ưu đãi đến 300.000đ khi thanh toán qua VNPay
Tham gia Thu Cũ Đổi Mới hỗ trợ lên đến 5 triệu (Xem Chi Tiết)
Giá trên không áp dụng Thu Cũ Đổi Mới</div>
                </div>
            </div>
            <div class="row ">
                <div class="col-12" style="padding:20px">
                  
                 <div >
                    <a href="thongtinthanhtoan.php">
                          <h1>thanh toán </h1>
                    </a>
                 </div>

                </div>
            </div>
         </div>  
</section>
</div>
<div >
    <?php include "footer.php" ?>

</div>
</body>
</html>