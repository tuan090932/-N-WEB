

<?php
//include auth_session.php file on all user panel pages
//include("auth_session.php");

require_once ('../config/config.php');
//require_once ('../insertdata/insert.php');
require_once ('auth_session.php');//xac minh xem login chua va khoi tao session
?>
<!DOCTYPE html>
<html>
<head>



  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

  <link rel="stylesheet" href="demo.css">



<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
    

           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  

        <!--   <input type="text" class="form-control" id="live_search"autocomplete="off" placeholder="Search..." >-->
    <link rel="stylesheet" href="dashboard.css">
    <meta charset="utf-8">
    <title>Dashboard - Client area</title>
    <link rel="stylesheet" href="style.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.2/css/all.css" />

<!-- Bootstrap CDN -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

</head>

<header>

<div>
<img  src="../img/dashboard.png" class="w-100" >
</div>

<div class="container-fluid bg-dark p-3  " style="" >
  <div class="row">
    <div class="col-3 text-center">
   <a href="dashboard.php"  class="btn btn-primary">    <h9>home</h1> </a>   
    </div>

     <div class="col-3 text-center">
     <a href="thongtinuser.php"class= "btn btn-primary" ><h9>thông tin người dùng</h2></a>   
     </div>

    <div class="col-2 text-center">
    <a class="btn btn-primary" href="thanhtoan.php" role="button"><h9>giỏ hàng</h2></a> 
    </div>

    <div class="col-2 text-center">
    <a class="btn btn-primary" href="logout.php" role="button"><h9>Logout</h2></a> 
    </div>

    <div class="col-2 text-center">
    <a class="btn btn-primary" href="tinhtrangdonhang.php" role="button"><h9>tình trạng đơn hàng</h2></a> 
    </div>


  </div>




</div>




<head>
<link rel="stylesheet" href="demo.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>

<body>

<div>
<div class="text-center" >
        <h1> hello, <?php echo $_SESSION['username']; ?>!</h1>
  
</div>


</header>