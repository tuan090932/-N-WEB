<?php
//include auth_session.php file on all user panel pages
//include("auth_session.php");
session_start();
require_once ('../config/config.php');
//require_once ('../insertdata/insert.php'); file này chạy thì sẽ cập nhập lại data trong insert(-> những thao tác xóa, sửa bên admin , sẽ bị update lại hết)

require_once ('auth_session.php');//xac minh xem login chua va khoi tao session
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
    
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.2/css/all.css" />

<!-- Bootstrap CDN -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<?php
include "header.php";
?>


<body>

<div style="margin:30px" >
  <div id="myCarousel" class="carousel slide" data-ride="carousel" style="margin-top:40px">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>
    <!-- Wrapper for slides -->
    <div class="carousel-inner">
      <div class="item active">
        <img src="../img/trangchu.png" alt="Los Angeles" style="width:80%;margin-left:150px;">
        <div class="carousel-caption">
          <h3>Los Angeles</h3>
          <p>LA is always so much fun!</p>
        </div>
      </div>
      <div class="item">
      <div class="carousel-caption">
          <h3>Chicago</h3>
          <p>Thank you, Chicago!</p>
      </div>
         <img src="../img/trangchu1.png" alt="Chicago" style="width:80%;margin-left:150px;">
      </div>
      <div class="item">
        <img src="../img/trangchu2.png" alt="New York" style="width:80%;:px;margin-left:150px;">
        <div class="carousel-caption">
          <h3>New York</h3>
          <p>We love the Big Apple!</p>
        </div>
      </div>
  
    </div>
    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>
</header>


<body>
   

</html>

<?php
$sql = "SELECT * FROM product";
$result = $mysqli->query($sql);//mục đích hiển thị tất cả sản phẩm lên 
//khai báo như này nó tồn tại trong file dashboard and use it as varible bình thường
?>



<section class="rounded" style="  border-style: solid; border-width: 1px;margin:30px">

  <div class="text-center" style="margin:0px; background-color: red;font-size: 40px;">
      ĐIỆN THOẠI NỔI BẬT NHẤT 2022
  </div>


  <div class=" "  id="result"style="border-style: solid; border-width: 1px ;" >
    <div class="row text-center " >
    <?php  while ($row = $result->fetch_assoc()) {?>
        <div class="col-md-4 col-sm-6 my-3 my-md-0 " >
               <a  id="<?php echo $row["id"] ?>" > <div class="card shadow" id="align" style="margin-top: 30px"> <!-- mỗi lần duyệt tạo ra 1 card shadow của id đó --> 
                         <div class="text-center">
                          <h1 style="color:#7FFFD4">
                            <?php
                            $idsanphamhientai = $row["brand_id"];                      
                            //mục đích là lấy brand hiện tại  sản phẩm để ở header card shadow
                            $sql = "SELECT  *FROM brand where id=$idsanphamhientai";
                            $resultbrand = $mysqli->query($sql);
                            $rowbrand = $resultbrand->fetch_assoc();
                            echo $rowbrand["name"];   //hiển thị tên thương hiệu hiện tại ra                     
                            ?>
                          </h1>
                       </div>


                        <div >
                             <img  src="<?php echo $row["image"]?>" alt="Image1"class="img-fluid" alt="Responsive image"style="margin-top: 30px" >  
                        </div>
                            <!--../ là thoát ra khỏi folder hiện tại -> ra iphone(xong rồi truy cập vô img, và product1 để lấy ảnh) -->
                          <!--..      <img src="../img/product1.jpg" alt="Image1" class="img-fluid card-img-top"> -->
                         <!-- //thiếu echo là nó k xuất ra chuổi,echo xuất ra -->                
                            <div class="card-body">
                                <h5 class="card-title"> <?php echo $row["name"] ?> </h5>
                                <h6>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="far fa-star"></i>
                                </h6>
                                <p class="card-text">
                                    <h1>
                                      điện thoại giá tốt
                                    </h1>
                                </p>
                                <h5>
                                    <h3><s class="text-secondary">$40000</s></h3>
                                    <span class="price">  <h1> <?php echo $row["price"] ?> </h1>    </span>
                                </h5>

                                <div>
                                  <form action="thanhtoan.php" method="post">
                                  
                                   <!--hidden là để gửi 1 biến id lên thanhtoan.php để lưu vô giỏ hàng session-->
                                     <input type="hidden" name="idsanpham" value="<?php echo $row["id"]?>">
                                     <input type="submit" name="submit" value="thanhtoan" style="font-size:20px;background:red">
                                    
                                  </form>
                                </div>                              
                             </div>                   
                            </div></a>  
              </div>
           <?php  }?> 
       </div>
       <div>
     <img  src="../img/bannerweb-min_3x.jpg" class="w-100" >
  </div>
</section>




<?php
include "footer.php";
?>
