<?php
require_once ('auth_session.php');
include "header.php";
?>

<!DOCTYPE html>
<html>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="/admin/admin.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
        <!--   <input type="text" class="form-control" id="live_search"autocomplete="off" placeholder="Search..." >-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.2/css/all.css" />
<!-- Bootstrap CDN -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">


<?php
require_once ('../config/config.php');

if(!isset($_SESSION)) 
{ 
    session_start(); //khoi tao session khi chua co
} 
$user = $_SESSION['username'];
//muốn so sánh với 1 chuổi phải thêm 2 dấu nháy
$qry="SELECT * FROM users where username='$user'";
$result = $mysqli->query($qry);
$row = $result->fetch_assoc();//vì chắc chắn truy vấn này trả về 1 row nên k cần while để lặp
$name = $row["username"];
$password1 = $row["password"];
$email=$row["email"];
$ngaytao=$row["create_datetime"];
        //truy vấn lấy thông tin user
//tạo 1 session lưu password của user hiện tại
?>

<div class="text-center">
     <h1> thông tin người dùng </h1>
</div>
<div>



<table class="table table-dark">
  <thead>
    <tr>
      <th scope="col" > <div class="text-center">  họ tên </div> </th>
      <th scope="col">  <div class="text-center">  <?php echo $name ?> </div>           </th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row"> <div class="text-center">  email</div>     </th>
      <td>   <div class="text-center">  <?php echo $email ?> </div>     </td>
    </tr>
    <tr>
      <th scope="row">    <div class="text-center">  password </div>     </th>
      <td><div class="text-center">  <?php echo $password1 ?> </div>    </td>
    </tr>
    <tr>
      <th scope="row">  <div class="text-center"> ngày tạo nick </div>                 </th>
      <td>  <div class="text-center">  <?php echo $ngaytao ?>   </div>    </td>
    </tr>
  </tbody>
</table>
</div>
<div class="text-center"style="margin:30px;">
     <a href="dashboard.php"  class="btn btn-primary"> <h1>quay về trang chủ</h1> </a>   
</div>







<div class="container mt-3 text-center">
  <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModal">
 <h1> sửa mật khẩu </h1>  
  </button>
</div>

<!-- The Modal -->
<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">mật khẩu mới là  </h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
    <!-- code form ở đây-->

    <form class="form" action="thaydoimackhau.php" method="post">
    
        <input type="text" class="login-input" name="passwordnew" placeholder="mậc khẩu mới của bạn là" required />
  
        <input type="submit" name="submit"  class="login-button">
      
    </form>
    <div>  </div>
      </div>
      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>


<div style="margin-top:100px">
</div><!-- tạo khoảng cách  -->
<?php


include "footer.php";

?>


