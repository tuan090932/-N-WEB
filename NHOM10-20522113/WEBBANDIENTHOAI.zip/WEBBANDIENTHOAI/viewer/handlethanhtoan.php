
<script>
    if ( window.history.replaceState ) {
        window.history.replaceState( null, null, window.location.href );
    }
</script>

<?php
  session_start();
require_once ('../config/config.php');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // removes backslashes
    $username = ($_REQUEST['name']);//get
    //escapes special characters in a string
    $email    = ($_REQUEST['email']);//get
    $sdt    = ($_REQUEST['sdt']);//get
    $address    = ($_REQUEST['address']);//get
    $message    = ($_REQUEST['message']);//get
    //echo $_SESSION['namesp'];
    $mamesp=$_SESSION['namesp'];
    
    $brandid= $_SESSION['brandid'];


    $sql = "SELECT  *FROM brand where id=$brandid";
    $result = $mysqli->query($sql);
    $row = $result->fetch_assoc();
   // echo $row["name"];//get name brand
    $namebrand = $row["name"];

 $idsanpham = $_SESSION['idsanpham'];
$sql = "SELECT  *FROM product where id=$idsanpham";
$result = $mysqli->query($sql);
$row = $result->fetch_assoc();
//echo $row["price"];//get name brand
$price = $row["price"];
//echo $price;

// PHP program to pop an alert
// message box on the screen
  
// Display the alert box 
    $datatime = date("Y-m-d H:i:s");

    $query    = "INSERT into `bill` (name, sdt,mail,noinhan, gichu,tonggia,tinhtrang,ngaymua,brand,loaisanpham)
    VALUES ('$username','$sdt','$email', '$address','$message ',$price,0, '$datatime','$namebrand','$mamesp')";

 
    $result   = mysqli_query($mysqli, $query);
    if ($result) {
        echo "<div class='text-center'>
              <h1>thanh toán thành công bạn vui lòng kiểm tra trạng thái giao hàng </h1><br/>
              </div>
              <a href='dashboard.php' '> <h2>    trở về trang chủ bấm đây </h2> </a>";



    } else {
        echo "<div class='form'>
              <h3>thanh toán thất bại vui lòng thanh toán lại </h3><br/>
              <p class='link'>Click here to <a href='dashboard.php'>mua hàng lại</a> again.</p>
              </div>";
    }
}
?>

