
<?php 


require_once ('../../config/config.php');
require_once ('auth_sessionadmib.php');
include "headeradmin.php";



?>

       <style>
        table {
            margin: 0 auto;
            font-size: large;
            border: 1px solid black;  
        }
 
        h1 {
            text-align: center;
            color: #006600;
            font-size: xx-large;
            font-family: 'Gill Sans', 'Gill Sans MT',
            ' Calibri', 'Trebuchet MS', 'sans-serif';
        }
 
        td {
            background-color: #E4F5D4;
            border: 1px solid black;
        }
 
        th,
        td {
            font-weight: bold;
            border: 1px solid black;
            padding: 10px;
            text-align: center;
            width: 100px;
        }
 
        td {
            font-weight: lighter;
        }
    </style>


<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <title>Document</title>
</head>



<?php 

$result    = "SELECT * FROM `bill`";
$result = mysqli_query($mysqli, $result);
$soluongdonhanghientai= mysqli_num_rows($result);//đếm sô lượng đơn hàng 


//đếm đơn được duyệt rồi 
$duocduyet    = "SELECT * FROM `bill` where tinhtrang=1 ";
$duocduyet = mysqli_query($mysqli, $duocduyet);
$soluongdonhangduocduyet = mysqli_num_rows($duocduyet);


//đếm đơn chưa được duyệt 
$chuaduocduyet    = "SELECT * FROM `bill` where tinhtrang=0 ";
$chuaduocduyet = mysqli_query($mysqli, $chuaduocduyet);
$soluongdonhangchuaduocduyet = mysqli_num_rows($chuaduocduyet);




?>


<div class="text-center" style="margin-top:40px">
       <h1>số lượng đơn hàng hiện tại là <?php echo $soluongdonhanghientai ?>    </h1>    
</div>


<div class="text-center row " style="margin-top:40px">

    <div class="col-6">
        <h1> số lượng đơn hàng được duyệt là <?php echo $soluongdonhangduocduyet ?></h1>

     </div>

     <div class="col-6">
     <h1> số lượng đơn hàng chưa được  duyệt là <?php echo $soluongdonhangchuaduocduyet ?></h1>

     </div>




      
</div>





<section  style="text-align:center;">



  <table>
          <tr>   
              <th>mail</th>
              <th>gia</th>
              <th>tinhtrang</th>
              <th>sdt</th>
              <th>dia chi</th>
              <th>ghichu</th>
          </tr>

          <?php
              // LOOP TILL END OF DATA
              while($row=$result->fetch_assoc())
              {

                  
          ?>
          <tr>
              <!-- FETCHING DATA FROM EACH
                  ROW OF EVERY COLUMN -->
              <td><?php echo $row['mail'];?></td>
              <td><?php echo $row['tonggia'];?></td>
              <td><?php  if ($row['tinhtrang']==0){
                  echo "đơn hàng chưa được duyệt ";

              }
              else{
                  echo "<p style='color:red'>đả duyệt</p>";
              }
              
              
              
              
              ?></td>


              <td><?php echo $row['sdt'];?></td>
              <td style="width: 250px;"><?php echo $row['noinhan'];?></td>
              <td style="width: 250px;"><?php echo $row['gichu'];?></td>
              
              <!-- file php run top direct down it like html but code this it like have file method and action  -->
           
              <td>
                  <div>
                               <form action="../index1.php" method="post"><!-- file này mục đích là set lại tình trạng của đơn hàng đó ->cho nó về đả duyệt rùi  -->
                                
                                 
                                   <input type="hidden" name="duyet" value="<?php echo $row["id"]?>"><!--vì thẻ submit nên k nhập j hết value=""-> vậy ta setup value= id để lấy đc khi gọi post(delete) -->
                                   <input type="submit" value="duyet"  class="btn btn-primary"><!--tên thôi-->
                                  
                                </form>
                  </div>


              </td>

          </tr>   
          <?php
              }
          ?>
    </table>


</section>

