

<script>
    if ( window.history.replaceState ) {
        window.history.replaceState( null, null, window.location.href );
    }
</script>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<?php


require_once ('../../config/config.php');
require_once ('auth_sessionadmib.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') { //if ($_POST) này nó có thể lưu trử input trống xử lý nó bằng cái dưới
    // removes backslashes
    $iddelete = $_POST['delete']; //get//POST MỚI LẤY ĐƯỢC REQUEST KHÔNG LẤY ĐC

    $sql = "DELETE FROM product WHERE id=$iddelete";

    $result= mysqli_query($mysqli, $sql);

    echo "xóa thành công";
    echo "  <p class='link'>Click here to <a href='homeadmin.php'>quay về home</a></p>";


}



?>