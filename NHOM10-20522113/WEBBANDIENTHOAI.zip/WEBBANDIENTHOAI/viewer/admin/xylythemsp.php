
<script>
    if ( window.history.replaceState ) {
        window.history.replaceState( null, null, window.location.href );
    }
</script>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<?php

require_once ('auth_sessionadmib.php');
require_once ('../../config/config.php');//số châm rất quan trọng chấm đầu là vô viewer . chấm 2 là voo model 
if ($_SERVER['REQUEST_METHOD'] === 'POST') {//if ($_POST) này nó có thể lưu trử input trống xử lý nó bằng cái dưới
    // removes backslashes
    $username = ($_REQUEST['name']);//get
    //escapes special characters in a string
    $price    = ($_REQUEST['price']);//get
    $image = ($_REQUEST['image']);//ghet  
    $brand_id = ($_REQUEST['brand_id']);//ghet  

  
    $query    = "INSERT into `product` (name, price, image, brand_id)
                 VALUES ('$username', '$price', '$image', '$brand_id')";

          
    $result   = mysqli_query($mysqli, $query);
    if ($result) {
        echo "<div class='form'>
              <h3>bạn đả thêm thành công </h3><br/>
              <p class='link'>Click here to <a href='homeadmin.php'>quay về home</a></p>
              </div>";
    } else {
        echo "<div class='form'>
              <h3>thêm thất bại</h3><br/>
             
              </div>";
    }
}

?>
