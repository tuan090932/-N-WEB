
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
    
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.2/css/all.css" />




<?php
// PHPMailer classes into the global namespace
use PHPMailer\PHPMailer\PHPMailer; 
use PHPMailer\PHPMailer\Exception;
// Base files 
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

require_once ('../config/config.php');

//if ($_POST) này nó có thể lưu trử input trống xử lý nó bằng cái dưới
    // removes backslashes

//get
//escapes special characters in a string


$id = $_REQUEST['duyet'];//lấy được id của bill

$idbill=(string)$id;
$bodymail = "mả đơn hàng của bạn là $idbill";


$sql = "UPDATE bill SET tinhtrang=1 WHERE id=$id";
//echo $sql;          
$result   = mysqli_query($mysqli, $sql);


$sql = "SELECT  *FROM bill  where id=$id ";
$result = $mysqli->query($sql);


$row = $result->fetch_assoc();//get 1 row when press button


$a=$row["mail"];//biến a lưu chử mail của người mua hàng 

//echo '<script type="text/javascript">alert("'.$a.'");</script>';


// create object of PHPMailer class with boolean parameter which sets/unsets exception.
$mail = new PHPMailer(true);                              
try {
    $mail->isSMTP(); // using SMTP protocol                                     
    $mail->Host = 'smtp.gmail.com'; // SMTP host as gmail 
    $mail->SMTPAuth = true;  // enable smtp authentication                             
   // $mail->Username = 'gietconheo88@gmail.com';  // sender gmail host    
    $mail->Username = 'gietconheo88@gmail.com';          
    $mail->Password = 'thdsghtbxfdraqjb'; // sender gmail host password                          
    $mail->SMTPSecure = 'tls';  // for encrypted connection                           
    $mail->Port = 587;   // port for SMTP     

    $mail->setFrom('gietconheo88@gmail.com', "Sender"); // sender's email and name
    $mail->addAddress($a, "Receiver");  // receiver's email and name


    $mail->Subject = 'BILL ';
    $mail->Body    = $bodymail ;


   


    $mail->send();
    echo "<div class='text-center'>
    <h1>bạn đả duyệt sản phẩm thành công đơn hàng sẽ được gửi tới mail khách hàng</h1><br/>
    </div>";
} catch (Exception $e) { // handle error.
    echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
}
?>