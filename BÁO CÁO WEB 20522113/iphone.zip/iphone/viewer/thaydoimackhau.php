

<?php
require_once ('auth_session.php');
require_once ('../config/config.php');
echo isset($_POST['submit']);
 //require_once ('../auth_session.php');
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['submit'])) {
        $passwordnew = ($_POST['passwordnew']); // removes backslashes  
        $userhientai = $_SESSION['username'];//thay doi password user hiện tại
        $sql = "UPDATE users SET password='$passwordnew' WHERE username='$userhientai'";  
        $result   = mysqli_query($mysqli, $sql);//truy vấn thực thiện câu lệnh của biến $sql
        header("Location: dashboard.php");
        // Check user is exist in the database
    }
}
?>