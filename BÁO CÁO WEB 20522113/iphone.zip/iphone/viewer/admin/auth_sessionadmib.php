
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

<?php
   

    if(!isset($_SESSION)) 
    { 
        session_start(); //khoi tao session khi chua co
    } 


    if(!isset($_SESSION["usernameadmin"])){
        echo "<div class='text-center'>
        <h1>bạn vui lòng đăng nhập trước khi vào trang </h1><br/>
        <h3 class='link'>Click here to <a href='admin.php'>Login</a> again.</h3>
        </div>";
        exit();//tu day ve sau code se thoat
    }


?>