
<?php 


require_once ('../../config/config.php');
require_once ('auth_sessionadmib.php');
include "headeradmin.php";


$result    = "SELECT * FROM `users`";
$result = mysqli_query($mysqli, $result);
$soluonguserhientai = mysqli_num_rows($result)//điếm số lượng user hiện tại






?>
<style>
        table {
            margin: 0 auto;
            font-size: large;
            border: 3px solid black;

          
        }
 
        h1 {
            text-align: center;
            color: #006600;
            font-size: xx-large;
            font-family: 'Gill Sans', 'Gill Sans MT',
            ' Calibri', 'Trebuchet MS', 'sans-serif';
        }
 
        td {
            background-color: #E4F5D4;
            border: 1px solid black;
        }
 
        th,
        td {
            font-weight: bold;
            border: 1px solid black;
            padding: 10px;
            text-align: center;
            width: 100px;
        }
 
        td {
            font-weight: lighter;
        }
    </style>


<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <title>Document</title>
</head>

<div class="text-center" style="margin-top:40px">
    <h1>số lượng user hiện tại là  <?php echo $soluonguserhientai ?></h1>
</div>


  <table>
            <tr>   
                <th>id</th>
                <th>tên</th>
                <th>email</th>
                <th>password</th>
            </tr>

            <?php
                // LOOP TILL END OF DATA
                while($row=$result->fetch_assoc())
                {             
            ?>
            <tr>
                <!-- FETCHING DATA FROM EACH
                    ROW OF EVERY COLUMN -->
                <td><?php echo $row['id'];?></td>
                <td><?php echo $row['username'];?></td>
                <td><?php echo $row['email'];?></td>
                <td><?php echo $row['password'];?></td>       
                <!-- file php run top direct down it like html but code this it like have file method and action  -->
        
            </tr>   
            <?php
                }
            ?>
    </table>