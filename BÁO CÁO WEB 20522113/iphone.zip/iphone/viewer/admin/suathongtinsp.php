
<?php require_once ('auth_sessionadmib.php'); ?>

<div class="container mt-3 text-center">
  <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModal" style="width: 250px;font-size:30px">
        <h1 style="font-size:20px;color:white"> sửa thông tin sẩn phẩm  </h1>  
  </button>
</div>

<!-- The Modal -->
<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">sửa thông tin là </h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
    <!-- code form ở đây-->

    <form class="form" action="xulysuasp.php" method="post">
        <!--Grid row-->
        <div class="row">
            <div class="col-md-6">
                <div class="md-form mb-0">
                    <input type="text" id="name" name="name" class="form-control"><!--vì value là nhập vào nên value="nhập"-> gọi name sẻ lấy đc tất cả -->
                    <label for="name" class="">name</label>
                </div>
            </div>
            <div class="col-md-6">
                <div class="md-form mb-0">
                    <input type="text" id="email" name="price" class="form-control">
                    <label for="email" class="">price</label>
                </div>
            </div>
            <!--Grid column-->

        </div>
        <!--Grid row-->

        <!--Grid row-->
        <div class="row">
            <div class="col-md-6">
                <div class="md-form mb-0">
                    <input type="text" id="subject" name="image" class="form-control">
                    <label for="subject" class="">image</label>
                </div>
            </div>

            <div class="col-md-6">
                <div class="md-form mb-0">
                    <input type="text" id="address" name="brand_id" class="form-control">
                    <label for="address" class="">brand_id</label>
                </div>
            </div>
        </div>

        <input type="submit" name="submit" value="sửa" class="login-button">
        <input type="hidden" name="sua" value="<?php echo $row["id"]?>">
    </form>


    
    <div>  </div>
      </div>
      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>