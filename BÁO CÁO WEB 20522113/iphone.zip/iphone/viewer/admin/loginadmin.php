<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

<?php
//xử lý login 
 session_start();
 require_once ('../../config/config.php');
 //require_once ('../auth_session.php');
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['usernameadmin'])) {
        $username = ($_POST['usernameadmin']);    // removes backslashes
        $password = ($_POST['passwordadmin']);
        // Check user is exist in the database
        $query    = "SELECT * FROM `adminne` WHERE username='$username'
                     AND password='" . ($password) . "'";
                     
        $result = mysqli_query($mysqli, $query);
        $rows = mysqli_num_rows($result);
        if ($rows == 1) {
            $_SESSION['usernameadmin'] = $username;

            
            // Redirect to user dashboard page
            header("Location: homeadmin.php");
            // Redirect to user dashboard page
         
        } else {
            echo "<div class='text-center'>
                  <h3>sai mậc khẩu bạn vui lòng đăng nhập lại</h3><br/>
                  <p class='link'>Click here to <a href='admin.php'>sign in </a> again.</p>
                  </div>";
        }
    } else {
    }
}

?>