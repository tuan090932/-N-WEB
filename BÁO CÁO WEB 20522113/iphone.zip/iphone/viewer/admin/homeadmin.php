<!-- code hearder cua admin  -->


<?php

require_once ('../../config/config.php');
require_once ('auth_sessionadmib.php');



//include auth_session.php file on all user panel pages
//include("auth_session.php");
include "headeradmin.php"
?>
<!DOCTYPE html>
<html>
<div>

</header>

  <style>
        table {
            margin: 0 auto;
            font-size: large;
            border: 1px solid black;

          
        }
      
 
        h1 {
            text-align: center;
            color: #006600;
            font-size: xx-large;
            font-family: 'Gill Sans', 'Gill Sans MT',
            ' Calibri', 'Trebuchet MS', 'sans-serif';
        }
 
        td {
            background-color: #E4F5D4;
            border: 1px solid black;
        }
 
        th,
        td {
            font-weight: bold;
            border: 1px solid black;
            padding: 20px;
           
          
            text-align: center;
            width: 100px;
        }
 
        td {
            font-weight: lighter;
        }

      


    </style>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <title>Document</title>
</head>


<?php 
//mysqli_num_rows ham nay dem so hang result no khac voi fetch_assoc() -> duyet qua tat ca row 
$result    = "SELECT * FROM `product`";
$result = mysqli_query($mysqli, $result);
$soluongsanphamhientai=mysqli_num_rows($result);

$brand    = "SELECT * FROM `brand`";
$brand = mysqli_query($mysqli, $brand);
$soluongbrandhientai=mysqli_num_rows($brand);




?>


<body>

<div class="text-center row" style="margin-top:40px">
    <div class="col-6">

    <h1>số lượng  sản phẩm hiện tại là  <?php echo $soluongsanphamhientai ?> </h1>  


    </div>

    <div class="col-6">
    <h1>số lượng thương hiệu hiện tại là  <?php echo $soluongbrandhientai ?> </h1> 


    </div>


     
       
    


</div>
   

   <section>
       
<div class="container mt-3 text-center">
  <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModal" style="width: 250px;font-size:30px;margin-bottom:30px">
            <h1 style="font-size:20px;color:white;"> them  </h1>  
  </button>
</div>

<!-- The Modal -->
<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">thêm thông tin sản phẩm </h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
    <!-- code form ở đây-->
    



<form class="form" action="xylythemsp.php" method="post">

<!--Grid row-->
<div class="row">


    <div class="col-md-6">
        <div class="md-form mb-0">
            <input type="text" id="name" name="name" class="form-control"><!--vì value là nhập vào nên value="nhập"-> gọi name sẻ lấy đc tất cả -->
            <label for="name" class="">name</label>
        </div>
    </div>


 
    <div class="col-md-6">
        <div class="md-form mb-0">
            <input type="text" id="email" name="price" class="form-control">
            <label for="email" class="">price</label>
        </div>
    </div>
    <!--Grid column-->

</div>
<!--Grid row-->

<!--Grid row-->
<div class="row">
    <div class="col-md-6">
        <div class="md-form mb-0">
            <input type="text" id="subject" name="image" class="form-control">
            <label for="subject" class="">image</label>
        </div>
    </div>

    <div class="col-md-6">
        <div class="md-form mb-0">
            <input type="text" id="address" name="brand_id" class="form-control">
            <label for="address" class="">brand_id</label>
        </div>
    </div>



</div>

<input type="submit" name="submit" value="thêm" class="login-button">


</form>

    
    <div>  </div>
      </div>
      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>





        <!-- TABLE CONSTRUCTION -->
 <table>
            <tr>   
                <th>price</th>
                <th>name</th>
                <th>ảnh minh họa</th>
            </tr>

            <?php
                // LOOP TILL END OF DATA
                while($row=$result->fetch_assoc())
                {

                $idsanphamhientai = $row["id"];
            ?>
            <tr>
                <!-- FETCHING DATA FROM EACH
                    ROW OF EVERY COLUMN -->
                <td><?php echo $row['price'];?></td>
                <td><?php echo $row['name'];?></td>
                <td><img  src="<?php echo "../".$row["image"]?>" alt="Image1"style="  width: 100px; height: 100px" ></td>
                <!--               xóa ở đây         -->      
                
                
                <td>
                    <div>
                                 <form action="deleteMember.php" method="post">
                                                              
                                     <input type="hidden" name="delete" value="<?php echo $row["id"]?>"><!--vì thẻ submit nên k nhập j hết value=""-> vậy ta setup value= id để lấy đc khi gọi post(delete) -->
                                     <input type="submit" value="delete"  class="btn btn-primary mb1 bg-blue" style="font-size:20px;color:white;"   >     <!--tên thôi-->

                                           
                                  </form>
                    </div>
                           
                </td>
           

    
    
    
    
 
          <!--   sua san pham o day         -->     
<td>
        
<?php 
  
  $idsanphamhientai;

  

  
  ?>  

  <div >



 
 <div class="text-center"  > <!-- muốn tương tác cái nào điều chỉnh data-bs-target để tương tác còn lại gữ nguyên  -->
   <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModalsua"  >
            <h1 style="font-size:20px;color:white;"> sửa sản phẩm id hiện tại là  <?php echo $idsanphamhientai ?>   </h1> 
   </button>
 </div>

 <!-- The Modal -->
 <div class="modal" id="myModalsua">
  <div class="modal-dialog">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">phải nhập đúng id sẩn phẩm  mới sửa được</h4>

        <h1></h1>

        <button type="button" class="btn-close" data-bs-dismiss="myModalsua"></button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
      <form class="form" action="xulysuasp.php" method="post">
        <!--Grid row-->
        <div class="row">
            <div class="col-md-4">
                <div class="md-form mb-0">
                    <input type="text" id="name" name="name" class="form-control"><!--vì value là nhập vào nên value="nhập"-> gọi name sẻ lấy đc tất cả -->
                    <label for="name" class="">name</label>
                </div>
            </div>
            <div class="col-md-4">
                <div class="md-form mb-0">
                    <input type="text" id="email" name="price" class="form-control">
                    <label for="email" class="">price</label>
                </div>
            </div>

            <div class="col-md-4">
                <div class="md-form mb-0">
                    <input type="text" id="sanpham" name="idsanpham" class="form-control">
                    <label for="email" class="">id sản  phẩm</label>
                </div>
            </div>
            <!--Grid column-->

        </div>
        <!--Grid row-->

        <!--Grid row-->
        <div class="row">
            <div class="col-md-6">
                <div class="md-form mb-0">
                    <input type="text" id="subject" name="image" class="form-control">
                    <label for="subject" class="">image</label>
                </div>
            </div>

            <div class="col-md-6">
                <div class="md-form mb-0">
                    <input type="text" id="address" name="brand_id" class="form-control">
                    <label for="address" class="">brand_id</label>
                </div>
            </div>
        </div>

        <input type="submit" name="submit" value="sửa" class="login-button">
        <input type="hidden" name="sua" value="<?php echo $row["id"]?>">
    </form>



          
     </div>
        
    <!-- code form ở đây-->
    </div>         
    
</td>

    <td>
        <h1><?php echo $idsanphamhientai ?></h1>
    </td>


            </tr>   


            <?php
                }
            ?>
        </table>
</section>


   
</body>
</html>

