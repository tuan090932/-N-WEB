<?php
session_start();
session_destroy();//HỦY TẤT CẢ SESSION và quay lại trang login
header("Location: admin.php");