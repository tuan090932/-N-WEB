<?php
include "header.php";
require_once ('../config/config.php');//số châm rất quan trọng chấm đầu là vô viewer . chấm 2 là voo model 
require_once ('auth_session.php');//xac minh xem login chua va khoi tao session
?>
<?php 
//
//cần id sản phẩm và id người dùng 
$nguoimua =$_SESSION['username'];//biến username là biến khi người dùng đăng nhập sẽ hiển thị 
$result    = "SELECT * FROM `bill` where  name= '$nguoimua' ";//name trong database là khi người dùng nhập form -> nếu form nhập không trùng khớp với tên tạo nick thì điều kiện sai-> 0 có người mua do tên ảo
$result = mysqli_query($mysqli, $result);//lấy tất cả tên người mua trùng với tên người mua trong bill
?>
<table class="table table-dark">
  <thead>
    <tr>
      <th scope="" > <div class="text-center">  họ tên </div> </th>
      <th scope="">  <div class="text-center"> giá </div> 
      <th scope="">  <div class="text-center">  tình trạng </div>  </th>
    </tr>
  </thead>
  <tbody>
  <?php
  // LOOP TILL END OF DATA
  while($row=$result->fetch_assoc())
  {
?>
    <tr>
      <td scope="row"> <div class="text-center">  <?php echo $row['name'];?> </div> </td>

      <td scope="row">    <div class="text-center"> <?php echo $row['tonggia'];?></div>               </td>
      <td>         
             <td> <?php 
             if ($row['tinhtrang']==1){      
                echo "<p style='color:red'>đơn hàng đả được duyệt</p>";
             }
             else{
          echo "dơn hàng đàng chờ xử lý";
             };   
             ?></td>        
      </td>
    </tr>
    <?php
                }
            ?>

   
  </tbody>
</table>
<div style="margin-top:100px"></div>

<?php

include "footer.php";
?>







